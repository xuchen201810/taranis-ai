App({
  globalData: {
    lastDrones: []
  }
});
